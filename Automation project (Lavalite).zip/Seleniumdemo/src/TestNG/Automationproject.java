package TestNG;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;
public class Automationproject {
ExtentSparkReporter report;
ExtentReports extent;
ExtentTest test;
WebDriver driver;

@Parameters("browser")

//Crossbrowsering Testing Included

  @Test
  public void Facebook(String Sbrowser) throws InterruptedException, IOException {
	  String path="C:\\Users\\chandaka.vijay\\OneDrive - HCL Technologies Ltd\\Desktop\\project\\test-output\\Chrome_reports.html";
report=new ExtentSparkReporter(path);
extent=new ExtentReports();
extent.attachReporter(report);
test=extent.createTest("Home title validation");
test.info("Chrome browser opening");
switch(Sbrowser) {
case "Chrome Browser":
    System.setProperty("webdriver.chrome.driver","C:\\Users\\chandaka.vijay\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
	driver=new ChromeDriver();
	break;
case "Opera Browser":
	System.setProperty("webdriver.opera.driver","C:\\\\Users\\\\chandaka.vijay\\\\Downloads\\\\operadriver_win64\\\\operadriver_win64//operadriver.exe");
	driver=new OperaDriver();
}
driver.manage().window().maximize();
test.pass("Successfully opend Chrome browser");
test.info("Open the lava lite website");
driver.get("https://lavalite.org/client/login");
test.pass("Url opened");
test.info("Verify the title");
//Assertions Included
String actualtitle="Login - Lavalite";
String title = driver.getTitle();
System.out.println(title);
Assert.assertEquals(title, actualtitle);
test.pass("Title verified");
try 
{ 
//Create account
	
test.info("Open the sigin module");
driver.findElement(By.linkText("Sign Up")).click();
test.pass("Successfully opend sigin module");
driver.findElement(By.id("name")).sendKeys("Virat");
Assert.assertEquals(true, true);
driver.findElement(By.name("email")).sendKeys("Virat@gmail.com");
Assert.assertEquals(true, true);
driver.findElement(By.name("password")).sendKeys("Virat@123");
Assert.assertEquals(true, true);
driver.findElement(By.id("password_confirmation")).sendKeys("Virat@123");
driver.findElement(By.xpath("//*[@id=\"register\"]/button")).click();

//login

test.info("Open the Login module");
driver.navigate().to("https://lavalite.org/client/login");
test.pass("Successfully opend Login module");

//Apppchi Framwork Included 

FileInputStream fis=new FileInputStream(new File("C:\\Users\\chandaka.vijay\\OneDrive - HCL Technologies Ltd\\Desktop\\Login sheet.xlsx"));
XSSFWorkbook wb=new XSSFWorkbook(fis);
XSSFSheet sheet=wb.getSheet("Sheet1");
driver.findElement(By.name("email")).sendKeys(sheet.getRow(1).getCell(0).getStringCellValue());
Assert.assertEquals(true, true);
driver.findElement(By.name("password")).sendKeys(sheet.getRow(1).getCell(1).getStringCellValue());
Assert.assertEquals(true, true);
driver.findElement(By.xpath("//*[@id=\"login\"]/button")).click();

//modules
driver.navigate().to("https://lavalite.org/client");
test.info("Open the Marketplace module");
driver.findElement(By.xpath("/html/body/section/div/div/div[1]/aside/div/div/a[1]")).click();
test.pass("Successfully opend Marketplace module");
Thread.sleep(3000);
driver.navigate().back();    
test.info("Open the Orders module");
driver.findElement(By.xpath("/html/body/section/div/div/div[1]/aside/div/div/a[2]")).click();
test.pass("Successfully opend Orders module");
Thread.sleep(3000);

test.info("Open the Jobs module");
driver.findElement(By.xpath("/html/body/section/div/div/div[1]/aside/div/div/a[4]")).click();
test.pass("Successfully opend Jobs module");
Thread.sleep(3000);
driver.navigate().back();
driver.findElement(By.xpath("/html/body/section/div/div/div[1]/aside/div/div/a[5]")).click();
driver.findElement(By.xpath("/html/body/div/section[2]/div/div/aside/div/a")).click();
driver.findElement(By.id("name")).sendKeys("Ani");
driver.findElement(By.xpath("//*[@id=\"category\"]/option[4]")).click();
driver.findElement(By.id("provider")).sendKeys("Kalia");
driver.findElement(By.id("package")).sendKeys("java");
driver.findElement(By.id("provider")).sendKeys("Kalia");
driver.findElement(By.xpath("//*[@id=\"version\"]/option[5]")).click();
driver.findElement(By.xpath("//*[@id=\"visibility\"]/option[2]")).click();
driver.findElement(By.id("description")).sendKeys("Application tester");
driver.findElement(By.xpath("//*[@id=\"create-package-package\"]/div/div[8]/div/input[1]")).click();
driver.get("https://lavalite.org/my/packages");
driver.get("https://lavalite.org/client");
Thread.sleep(3000);
driver.navigate().to("https://lavalite.org/client/cart/order");
test.info("Open the Become a Seller module");
driver.findElement(By.xpath("/html/body/section/div/div/div[1]/aside/div/div/a[6]")).click();
test.pass("Successfully opend Become a Seller module");
}catch(Exception e)
{
	 System.out.println(e);
}

// Including Screenshots

TakesScreenshot scrShot =((TakesScreenshot)driver);
File SourceFile=scrShot.getScreenshotAs(OutputType.FILE);
File DestFile=new File("C:\\Users\\chandaka.vijay\\OneDrive - HCL Technologies Ltd\\Desktop\\java Automachine\\Lavalite_Automation.png");
Files.copy(SourceFile, DestFile);
Thread.sleep(3000);
driver.navigate().back();
driver.close();
}
  @AfterTest
public void closetest()
{
 extent.flush();
 driver.quit();
}
}